#include "apilib.h"

void HariMain(void)
{
	api_putchar('A');
	api_end();
}
