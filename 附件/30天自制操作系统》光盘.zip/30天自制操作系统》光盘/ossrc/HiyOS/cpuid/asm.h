/* HiyOS */
void asm_cpuid(int id_eax, int id_ecx, int *eax, int *ebx, int *ecx, int *edx);
void asm_rdtsc(int *high, int *low);
